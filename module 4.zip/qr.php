

<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">

    <title>Membership Qr Generator</title>
    <link rel="stylesheet" href="qrC.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="qr">
    <header>
        <h1>Membership card Qr generator</h1>

                            
    </header>
    <div class="menu">
        <input type="text" placeholder="Enter name">
        <br>
        <button>Generate QR Membership</button>
    </div>
    <div class="qrCode">
        <img src="" alt="qrcode">
    </div>
</div>

    <script src="scriptQR.js"></script>

</body>
</html>