 <?php

    $con= mysqli_connect("localhost", "root", "", "project") or die("Couldn't connect");
?>